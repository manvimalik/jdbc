package com.bank.exception;

public class AccountNotFoundException extends RuntimeException {
	/* creating exception class to handle all the exceptions */
	public AccountNotFoundException(final String s) {
		super(s);
	}
}
