package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class UserInformation {
	/* Taking the inputs from the user */

	private String userName;
	private int age;
	@Id
	@GeneratedValue
	private long accountNo;
	private String branch;
	private long balance;
	private String mobileNo;
	private String accountType;

	/* By using getter and setters we are getting and setting the values */
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long deposit) {
		this.balance = deposit;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/* using the toString for conversion of all the values and convert them */
	@Override
	public String toString() {
		return "UserInformation [userName=" + userName + ", age=" + age + ", accountNo=" + accountNo + ", branch="
				+ branch + ", balance=" + balance + ", mobileNo=" + mobileNo + ", accountType=" + accountType + "]";
	}

}
