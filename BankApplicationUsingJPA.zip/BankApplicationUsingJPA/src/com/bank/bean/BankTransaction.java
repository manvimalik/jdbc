package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class BankTransaction {
	/* All the transactions related information will be taken from the user */
    @Id
    @GeneratedValue
	private int transactionId;
	private long acNo;
	private long toAcc;
	private long oldBal;
	private long newBal;
	private String tranType;

	/* By getters and setters we are getting and setting the values */

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public long getAcNo() {
		return acNo;
	}

	public void setAcNo(long acNo) {
		this.acNo = acNo;
	}

	public long getToAcc() {
		return toAcc;
	}

	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}

	public long getOldBal() {
		return oldBal;
	}

	public void setOldBal(long oldBal) {
		this.oldBal = oldBal;
	}

	public long getNewBal() {
		return newBal;
	}

	public void setNewBal(long newBal) {
		this.newBal = newBal;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	/* Calling the to string method because string can store any variable */
	@Override
	public String toString() {
		return "BankTransaction [transactionId=" + transactionId + ", acNo=" + acNo + ", toAc=" + toAcc + ", oldBal="
				+ oldBal + ", newBal=" + newBal + ", tranType=" + tranType + "]";
	}

}
