package com.bank.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;

import com.bank.bean.UserInformation;

public class BankDaoImplTest {
	BankDaoImpl dao=new BankDaoImpl();

	public void createAcc_1() {
		UserInformation bank = new UserInformation();
		bank.setAccountType("savings");
		bank.setMobileNo("89657856");
		bank.setUserName("Manvi");
		bank.setBranch("del");
		bank.setAge(21);
		bank.setBalance(8000);
		long AccountNo = dao.createUserAccount(bank);
		Assert.assertEquals(12000, AccountNo);

	}

	// negative response
	// @Test
	public void retrieve_2() {
		UserInformation bank = new UserInformation();
		bank.setAccountType("savings");
		bank.setMobileNo("89657856");
		bank.setUserName("Manvi");
		bank.setBranch("del");
		bank.setAge(21);
		bank.setBalance(8000);
		bank.setAccountNo(1);

		long AccountNo = dao.retrievecreateUserAccount(1);

		Assert.assertEquals(8000, 1);

	}
	    
	  //Another method of junit for deposit(positive respones)
	    @Test
	    public void test() {
	        int balance=1000;
	        int result=balance+800;
	        int expectedResult=1800;
	        assertEquals(expectedResult,result);
	        System.out.println(expectedResult=result);
	    }
	    //Another method of junit for deposit(negative respones)
	    @Test
	    public void test1()
	    {
	        int balance2=1000;
	        int result2=balance2+800;
	        int expectedResult2=2800;
	        assertEquals(expectedResult2,result2);
	        System.out.println(expectedResult2=result2);
	    }
	    
	    //Another method of junit for withDraw(positive respones)
	    @Test
	    public void test2() {
	        int balance=1000;
	        int result=balance-800;
	        int expectedResult=200;
	        assertEquals(expectedResult,result);
	        System.out.println(expectedResult=result);
	    }
	    //Another method of junit for withDraw(negative respones)
	    @Test
	    public void test3()
	    {
	        int balance2=1000;
	        int result2=balance2-800;
	        int expectedResult2=2800;
	        assertEquals(expectedResult2,result2);
	        System.out.println(expectedResult2=result2);
	    }
	    
}
