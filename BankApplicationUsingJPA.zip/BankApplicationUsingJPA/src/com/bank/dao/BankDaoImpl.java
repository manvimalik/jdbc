package com.bank.dao;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.bank.bean.BankTransaction;
import com.bank.bean.UserInformation;

public class BankDaoImpl implements BankDao {

	private EntityManager entityManager;


	public BankDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}


	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}
	
	
	@Override
	public long createUserAccount(UserInformation user) {
		

		entityManager.persist(user);
		return user.getAccountNo();

	}

	@Override
	public long retrievecreateUserAccount(long accountNo) {
	
		UserInformation bankdet=entityManager.find(UserInformation.class, accountNo);
		long bal= bankdet.getBalance();
		return bal;
	}

	@Override
	public long depositMoney(long accountNo, long depositAmount) {
		UserInformation bank=entityManager.find(UserInformation.class, accountNo);
		long prebal=bank.getBalance();
		long deposit=prebal+depositAmount;
		bank.setBalance(deposit);
		entityManager.merge(bank);
		
		
	    BankTransaction transaction =new  BankTransaction();
	        transaction.setAcNo(accountNo);
	        transaction.setNewBal(deposit);
	        transaction.setOldBal(prebal);
	        transaction.setTranType("Credit");
	        entityManager.persist(transaction);

		
		
		
		return deposit;
	
	//UserInformation acc=entityManager.find(arg0, arg1)
		
	}

	@Override
	public long withdrawMoney(long accountNo, long withdrawlAmount) {
		UserInformation bank=entityManager.find(UserInformation.class, accountNo);
		long prebal=bank.getBalance();
		long withdraw=prebal-withdrawlAmount;
		bank.setBalance(withdraw);
		entityManager.merge(bank);
		
		
		  BankTransaction transaction =new  BankTransaction();
	        transaction.setAcNo(accountNo);
	        transaction.setNewBal(withdraw);
	        transaction.setOldBal(prebal);
	        transaction.setTranType("Debit");
	        entityManager.persist(transaction);
		return withdraw;
            
	}
	@Override
	public long transferFunds(long firstAcc, long secondAcc, long transferAmt) {
		// TODO Auto-generated method stub
		UserInformation bank=entityManager.find(UserInformation.class, firstAcc);
		long prebal=bank.getBalance();
		long updatebal=prebal-transferAmt;
		
		UserInformation bank1=entityManager.find(UserInformation.class, secondAcc);
		long prebal1=bank.getBalance();
		long updatebal1=prebal1+transferAmt;
		
		BankTransaction transaction =new  BankTransaction();
        transaction.setAcNo(firstAcc);
        transaction.setToAcc(secondAcc);
        transaction.setNewBal(updatebal);
        transaction.setOldBal(prebal1);
        transaction.setTranType("Debit");
        entityManager.persist(transaction);
		
		return updatebal ;
    }
	

	@Override
	public List<BankTransaction> printTransactions() {
		// TODO Auto-generated method stub
	      TypedQuery<BankTransaction> q=entityManager.createQuery("select b from BankTransaction b",BankTransaction.class);
	      List<BankTransaction> l=q.getResultList();
	      return l;
	}	}
	
	
