package com.bank.ui;

import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.bank.bean.BankTransaction;
import com.bank.bean.UserInformation;
import com.bank.exception.AccountNotFoundException;
import com.bank.service.BankService;
import com.bank.service.BankServiceImpl;

public class BankUi {
	/* calling the bank service to connect */
	/* Calling the scanner for taking inputs from the user */
	static Scanner scanner = new Scanner(System.in);
	static BankService service = new BankServiceImpl();

	public static void main(String[] args) {

		while (true) {/* printing the SOP statements */
			System.out.println("Welcome To Our Bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			/* Asking for user choice */
			System.out.println("Enter Your Choice");
			int choice = scanner.nextInt();
			/*
			 * Applying the different cases as per the different choices of the
			 * user
			 */
			switch (choice) {
			case 1:
				boolean custOkName = false;
				boolean custOkmNo = false;
				String name = null;
				String mNo = null;

				do {
					System.out.println("Enter Customer Name :");
					name = scanner.next();
					custOkName = service.isOkName(name);
					if (!custOkName) {
						System.out.println("Enter correct format of name");
					}
				} while (!custOkName);

				System.out.println("Enter your Age");
				int age = scanner.nextInt();

				do {
					System.out.println("Enter your Mobile No");
					mNo = scanner.next();
					custOkmNo = service.isOkmNo(mNo);
					if (!custOkmNo) {
						System.out.println("Enter the no correclty");
					}
				} while (!custOkmNo);

				System.out.println("Enter branch which you prefer");
				String branch = scanner.next();

				System.out.println("Enter Account Type(Savings Account/Current Account)");
				String type = scanner.next();

				System.out.println("Balance:");
				int balc = scanner.nextInt();
				/*
				 * Conversion of the the mobile no which is in string into
				 * Integer so that it will generate the account no on its own
				 */
				

				UserInformation user = new UserInformation();
				user.setUserName(name);
				user.setAge(age);
				user.setMobileNo(mNo);
				user.setBranch(branch);
				user.setAccountType(type);
				user.setBalance(balc);

				long accountNo=service.createUserAccount(user);

				System.out.println("Account Created");
				System.out.println("Your AccountNo is:" + accountNo);

				break;

			case 2:/*
					 * retrieving the customer account
					 */
				try {
					System.out.println("Enter Account No:");
					int acNo = scanner.nextInt();
					long users = service.retrievecreateUserAccount(acNo);
					System.out.println("Your Balance is :" + users);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 3:/* Depositing the amount */
				try {
					System.out.println("Enter the Account no:");
					int acNo1 = scanner.nextInt();
					System.out.println("Enter the amount you want to deposit:");
					int depositAmount = scanner.nextInt();
					long bal = service.depositMoney(acNo1, depositAmount);
					System.out.println(
							"Your account has been successfully credited \n" + "Your remaining balance " +service.retrievecreateUserAccount(acNo1));
				} catch (Exception e) {
					System.out.println("Please Enter Valid Account Number");
				}
				break;

			case 4:/* Withdrawing the amount */
				try {
					System.out.println("Enter the Account no:");
					long acNo2 = scanner.nextInt();
					System.out.println("Enter Withdraw Amount:");
					long withdrawlAmount = scanner.nextInt();

					long remainingBal = service.withdrawMoney(acNo2, withdrawlAmount);
					System.out.println("Youe Account has been successfully debited: \n" + "Your Remaining Balance is:"
							+ service.retrievecreateUserAccount(acNo2));
				} catch (Exception e) {
					System.out.println("Please Enter Valid Account Number");
				}
				break;
			case 5:/* Transfer of money from one account to another */
				try {
					System.out.println("Enter the Account number from which you want to transfer the money:");
					long FirstAccount = scanner.nextInt();
					System.out.println("Enter the Account number to which you want to transfer the money:");
					long SecondAccount = scanner.nextInt();
					System.out.println("Enter the Amount you want to transfer:");
					long amt = scanner.nextInt();
					long remainingBalance = service.transferFunds(FirstAccount, SecondAccount, amt);
					System.out.println("Amount successfully transferred \n" + "Remaining Balance" + remainingBalance);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 6:/* Showing the transaction details */
				try {
					System.out.println("Showing all the Transaction");
					List<BankTransaction> result = service.printTransactions();
					ListIterator<BankTransaction> lis = result.listIterator();
					while (lis.hasNext()) {
						System.out.println(lis.next() + " ");
					}
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());

				}
				break;

			case 7:/* Salutation */

				System.out.println("Thanks for Banking");
				System.exit(0);

			default:
				/*
				 * Default case which will be shown to the user when he will
				 * enter the wrong input
				 */
				System.out.println("Wrong Choice \n Transaction Failed");
				break;

			}

		}
	}
}