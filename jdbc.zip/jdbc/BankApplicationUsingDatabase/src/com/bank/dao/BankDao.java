package com.bank.dao;

import java.util.List;

import com.bank.bean.BankTransaction;
import com.bank.bean.UserInformation;

public interface BankDao {

	long createUserAccount(UserInformation user);

	long retrievecreateUserAccount(long accountNo);

	long depositMoney(long accountNo, long depositAmount);

	long withdrawMoney(long accountNo, long withdrawlAmount);

	long transferFunds(long firstAcc, long secondAcc, long transferAmt);

	List<BankTransaction> printTransactions();

	
}
