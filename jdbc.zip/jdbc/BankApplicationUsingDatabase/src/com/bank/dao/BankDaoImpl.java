package com.bank.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bank.bean.BankTransaction;
import com.bank.bean.UserInformation;

public class BankDaoImpl implements BankDao {


	@Override
	public long createUserAccount(UserInformation user) {
		

		// TODO Auto-generated method stub
		Connection conn;
		long value=0;
		try{
		conn=DBConnect.getConnection();
		Statement stamnt=conn.createStatement();
		PreparedStatement stamnt1=conn.prepareStatement("insert into BankAcc values(?,?,BankSeq2.nextval,?,?,?,?)");
		stamnt1.setString(1, user.getUserName());
		stamnt1.setLong(2, user.getAge());
		stamnt1.setLong(3, user.getAccountNo());
		stamnt1.setString(4, user.getBranch());
		stamnt1.setLong(4, user.getBalance());
		stamnt1.setString(5, user.getMobileNo());
		stamnt1.setString(6, user.getAccountType());
		int val=stamnt1.executeUpdate();
		if(val>0)
		{
			PreparedStatement stmnt1=conn.prepareStatement("select BankSeq2.currval from dual ");
			ResultSet val1=stmnt1.executeQuery();
			val1.next();
			value=val1.getLong(1);
			System.out.println("Account Created Succesfully");
		}
		}
		catch(Exception ae){
			System.out.println(ae);
		}
		return value;

	}

	@Override
	public long retrievecreateUserAccount(long accountNo) {
		// TODO Auto-generated method stub
		Connection conn;
		long value=0;
		
		try{
			conn=DBConnect.getConnection();
			PreparedStatement stmnt1=conn.prepareStatement("select balance from BankAcc where accountNo=?");
			stmnt1.setLong(1, accountNo);
			ResultSet val1=stmnt1.executeQuery();
			
			val1.next();
			value=val1.getLong(1);
		}catch(Exception ae)
		{
			System.out.println(ae);
		}
		return value;
	}

	@Override
	public long depositMoney(long accountNo, long depositAmount) {
		// TODO Auto-generated method stub
		Connection conn;
		long deposit=0;
		long value=0;
		conn=DBConnect.getConnection();
		try{
			
			PreparedStatement stmnt=conn.prepareStatement("select balance from BankAcc where accountNo=?");
            stmnt.setLong(1, accountNo);
            ResultSet val=stmnt.executeQuery();
            val.next();
            long prebal=val.getLong(1);
            deposit=prebal+depositAmount;
            PreparedStatement stmnt1=conn.prepareStatement("update BankAcc set balance=? where accountNo=?");
            stmnt1.setLong(1, deposit);
            stmnt1.setLong(2, accountNo);
            
            val=stmnt1.executeQuery();
            
            PreparedStatement stmt2 = conn.prepareStatement("insert into Transaction(transactionId,acNo,oldBal,newBal,tranType) values(BankSeq.nextval,?,?,?,?)");
            stmt2.setLong(1, accountNo);
            stmt2.setLong(2,prebal);
            stmt2.setLong(3,deposit);
            stmt2.setString(4,"C");
           int result2=stmt2.executeUpdate();
		}catch(Exception ae)
		{
			System.out.println(ae);
		}
		if(value>0){
			return deposit;
		}
		return 0;
	}

	@Override
	public long withdrawMoney(long accountNo, long withdrawlAmount) {
		// TODO Auto-generated method stub
		Connection conn;
		long withdrawn=0;
		long value=0;
		conn=DBConnect.getConnection();
		try{
			
			PreparedStatement stmnt=conn.prepareStatement("select balance from BankAcc where accountNo=?");
            stmnt.setLong(1, accountNo);
            ResultSet val=stmnt.executeQuery();
            val.next();
            long prebal=val.getLong(1);
            withdrawn=prebal-withdrawlAmount;
            PreparedStatement stmnt1=conn.prepareStatement("update BankAcc set balance=? where accountNo=?");
            stmnt1.setLong(1, withdrawn);
            stmnt1.setLong(2, accountNo);
            
            val=stmnt1.executeQuery();
            
            
            PreparedStatement stmt2 = conn.prepareStatement("insert into Transaction(transactionId,acNo,oldBal,newBal,tranType) values(BankSeq.nextval,?,?,?,?)");
            stmt2.setLong(1, accountNo);
            stmt2.setLong(2,prebal);
            stmt2.setLong(3,withdrawn);
            stmt2.setString(4,"D");
           int result2=stmt2.executeUpdate();
            
            
		}catch(Exception ae)
		{
			System.out.println(ae);
		}
		if(value>0){
			return withdrawn;
		}
		return 0;
	}
	@Override
	public long transferFunds(long firstAcc, long secondAcc, long transferAmt) {
		// TODO Auto-generated method stub
		long updatebal1=0;
        Connection conn = DBConnect.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("select balance from BankAcc where accountNo=?");
            stmt.setLong(1, firstAcc);
            ResultSet result=stmt.executeQuery();
            result.next();
            long firstbal=result.getInt(1);
           
            PreparedStatement stmt1 = conn.prepareStatement("select balance from BankAcc where accountNo=?");
            stmt1.setLong(1, secondAcc);
            ResultSet result1=stmt1.executeQuery();
            result1.next();
            long secondbal=result1.getInt(1);
           
         updatebal1=firstbal-transferAmt;
            long updatebal2=secondbal+transferAmt;
           
            PreparedStatement stmt3 = conn.prepareStatement("update BankAcc set balance=? where accountNo=?");
            stmt3.setLong(1,firstAcc);
            stmt3.setLong(2, updatebal1);
           
            long result2=stmt3.executeUpdate();
            
            PreparedStatement stmt4 = conn.prepareStatement("update BankAcc set balance=? where accountNo=?");
            stmt4.setLong(1,secondAcc);
            stmt4.setLong(2, updatebal2);
               
            long result3=stmt4.executeUpdate();
            
            
            
            PreparedStatement stmt5 = conn.prepareStatement("insert into Transaction values(BankSeq.nextval,?,?,?,?,?)");
            stmt5.setLong(1, firstAcc);
            stmt5.setLong(2, secondAcc);
            stmt5.setLong(3, firstbal);
            stmt5.setLong(4, updatebal1);
            stmt5.setString(5, "Debit");
            stmt5.executeUpdate();
            
            
            
        }catch(Exception e)
        {
            System.out.println(e);
        }    return updatebal1;
    }
	

	@Override
	public List<BankTransaction> printTransactions() {
		// TODO Auto-generated method stub
		 List<BankTransaction> transactionList = new ArrayList<>();
	        try (Connection connection = DBConnect.getConnection()) {
	            PreparedStatement statement = connection.prepareStatement("select * from Transaction");
	            ResultSet set = statement.executeQuery();
	            while (set.next()) {
	                BankTransaction transaction = new BankTransaction();
	            transaction.setTransactionId(set.getInt(1));
	                transaction.setAcNo(set.getInt(2));
	                transaction.setToAcc(set.getInt(3));
	                transaction.setOldBal(set.getInt(4));
	                transaction.setNewBal(set.getInt(5));
	                transaction.setTranType(set.getString(6));
	                transactionList.add(transaction);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	       
	        return transactionList;
	}	}
	
	
