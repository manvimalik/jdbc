package com.bank.bean;

public class BankTransaction {
	/* All the transactions related information will be taken from the user */

	private int transactionId;
	private int acNo;
	private int toAcc;
	private int oldBal;
	private int newBal;
	private String tranType;

	/* By getters and setters we are getting and setting the values */

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getAcNo() {
		return acNo;
	}

	public void setAcNo(int acNo) {
		this.acNo = acNo;
	}

	public int getToAcc() {
		return toAcc;
	}

	public void setToAcc(int toAcc) {
		this.toAcc = toAcc;
	}

	public int getOldBal() {
		return oldBal;
	}

	public void setOldBal(int oldBal) {
		this.oldBal = oldBal;
	}

	public int getNewBal() {
		return newBal;
	}

	public void setNewBal(int newBal) {
		this.newBal = newBal;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	/* Calling the to string method because string can store any variable */
	@Override
	public String toString() {
		return "BankTransaction [transactionId=" + transactionId + ", acNo=" + acNo + ", toAc=" + toAcc + ", oldBal="
				+ oldBal + ", newBal=" + newBal + ", tranType=" + tranType + "]";
	}

}
