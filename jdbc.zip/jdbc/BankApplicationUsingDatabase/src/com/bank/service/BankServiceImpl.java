package com.bank.service;

import java.util.List;

import com.bank.bean.BankTransaction;
import com.bank.bean.UserInformation;
import com.bank.dao.BankDao;
import com.bank.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	/* Connecting dao with Service */
	BankDao dao = new BankDaoImpl();

	/* calling method to create new account */
	@Override
	public long createUserAccount(UserInformation user) {
		return dao.createUserAccount(user);
	}

	/* calling method to retrieve account */
	@Override
	public long retrievecreateUserAccount(long accountNo) {
		long user = dao.retrievecreateUserAccount(accountNo);
		return user;
	}

	/* calling method to deposit money */
	@Override
	public long depositMoney(long accountNo, long depositAmount) {
		long balance = dao.depositMoney(accountNo, depositAmount);
		return balance;

	}

	/* calling method to withdraw money */
	@Override
	public long withdrawMoney(long accountNo, long withdrawlAmount) {
		long remainingBalance = dao.withdrawMoney(accountNo, withdrawlAmount);
		return remainingBalance;
	}

	/* calling method to transfer funds */
	@Override
	public long transferFunds(long firstAcc, long secondAcc, long transferAmt) {
		long remainingBal = dao.transferFunds(firstAcc, secondAcc, transferAmt);
		return remainingBal;
	}

	/* calling method to print transactions */
	@Override
	public List<BankTransaction> printTransactions() {
		List<BankTransaction> list = dao.printTransactions();

		return list;
	}
	/* method to check the naming conventions */

	@Override
	public boolean isOkName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*"))
			return true;
		else
			return false;
	}

	/* method to check mobile no requirements */
	@Override
	public boolean isOkmNo(String mNo) {
		if (mNo.matches("[6-9][0-9]{7}"))
			return true;
		else
			return false;
	}

}
